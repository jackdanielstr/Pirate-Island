// ═══════════════════════════════════════
// MODULO: CORE
// ═══════════════════════════════════════
function limiteCamera(){
  // Limiti per proiezione isometrica
  const s   = G.ISO_SCALE;
  const IW  = G.ISO_W * s, IH = G.ISO_H * s;
  // Estensione della mappa iso in coordinate schermo
  const mapW = (G.COLS + G.RIGHE) * IW / 2;
  const mapH = (G.COLS + G.RIGHE) * IH / 2;
  const pad  = 80;
  G.camX = Math.max(-mapW + pad, Math.min(canvas.width - pad, G.camX));
  G.camY = Math.max(-mapH + pad, Math.min(canvas.height - pad, G.camY));
}

function impostaInput(){
  // Mouse pan
  canvas.addEventListener('mousedown',e=>{
    if(e.button!==0) return;
    pan.attivo=true; pan.mosso=false;
    pan.startX=e.clientX; pan.startY=e.clientY;
    pan.camStartX=G.camX; pan.camStartY=G.camY;
    canvas.style.cursor='grabbing';
  });
  canvas.addEventListener('mousemove',e=>{
    const rect=canvas.getBoundingClientRect();
    const mx=e.clientX-rect.left, my=e.clientY-rect.top;
    const s=G.ISO_SCALE, IW=G.ISO_W*s, IH=G.ISO_H*s;
    const lx=mx-G.camX, ly=my-G.camY;
    G.hoverC=Math.floor((lx/IW*2+ly/IH*2)/2-.5);
    G.hoverR=Math.floor((ly/IH*2-lx/IW*2)/2+.5);
    // Sentiero drag-paint
    if(pan.attivo && G.modalitaCostruzione==='sentiero'){
      piazzaSentiero(G.hoverR,G.hoverC); return;
    }
    if(!pan.attivo) return;
    const dx=e.clientX-pan.startX, dy=e.clientY-pan.startY;
    if(Math.abs(dx)>4||Math.abs(dy)>4) pan.mosso=true;
    if(pan.mosso){ G.camX=pan.camStartX+dx; G.camY=pan.camStartY+dy; limiteCamera(); }
  });
  window.addEventListener('mouseup',e=>{
    if(pan.attivo){ pan.attivo=false; canvas.style.cursor=''; sentieroDrag=false; }
  });
  canvas.addEventListener('click',e=>{
    if(pan.mosso) return;
    cliccaMappa(e);
  });
  // Scroll wheel zoom (desktop)
  canvas.addEventListener('wheel',e=>{
    e.preventDefault();
    const rect=canvas.getBoundingClientRect();
    const mx=e.clientX-rect.left, my=e.clientY-rect.top;
    const zoomDelta=e.deltaY<0?1.1:0.91;
    applicaZoom(zoomDelta, mx, my);
  },{passive:false});

  // ── TOUCH: pan + pinch-to-zoom ──
  let pinch={attivo:false, dist0:0, zoom0:1, midX:0, midY:0, camX0:0, camY0:0};

  function distTocchi(t){ return Math.hypot(t[0].clientX-t[1].clientX, t[0].clientY-t[1].clientY); }
  function midTocchi(t,rect){ return {x:(t[0].clientX+t[1].clientX)/2-rect.left, y:(t[0].clientY+t[1].clientY)/2-rect.top}; }

  canvas.addEventListener('touchstart',e=>{
    e.preventDefault();
    if(e.touches.length===2){
      // avvia pinch
      pan.attivo=false;
      const rect=canvas.getBoundingClientRect();
      pinch.attivo=true;
      pinch.dist0=distTocchi(e.touches);
      pinch.zoom0=G.zoom;
      const mid=midTocchi(e.touches,rect);
      pinch.midX=mid.x; pinch.midY=mid.y;
      pinch.camX0=G.camX; pinch.camY0=G.camY;
    } else {
      pinch.attivo=false;
      const t=e.touches[0];

      // In modalità costruzione su mobile privilegia il tap
      // evitando che piccoli movimenti blocchino il piazzamento.
      if(G.modalitaCostruzione){
        pan.attivo=false;
        pan.mosso=false;
      }else{
        pan.attivo=true;
        pan.mosso=false;
        pan.startX=t.clientX;
        pan.startY=t.clientY;
        pan.camStartX=G.camX;
        pan.camStartY=G.camY;
      }
    }
  },{passive:false});

  canvas.addEventListener('touchmove',e=>{
    e.preventDefault();
    if(pinch.attivo && e.touches.length===2){
      const rect=canvas.getBoundingClientRect();
      const dist=distTocchi(e.touches);
      const scale=dist/pinch.dist0;
      const newZoom=Math.max(G.ZOOM_MIN, Math.min(G.ZOOM_MAX, pinch.zoom0*scale));
      // zoom centrato sul punto di pinch
      const ratio=newZoom/G.zoom;
      G.camX=pinch.midX-(pinch.midX-pinch.camX0)*ratio;
      G.camY=pinch.midY-(pinch.midY-pinch.camY0)*ratio;
      G.zoom=newZoom;
      limiteCamera();
      // aggiorna punto di partenza continuo per pan durante pinch
      const mid=midTocchi(e.touches,rect);
      const dxPan=mid.x-pinch.midX, dyPan=mid.y-pinch.midY;
      G.camX+=dxPan; G.camY+=dyPan;
      pinch.midX=mid.x; pinch.midY=mid.y;
      pinch.camX0=G.camX; pinch.camY0=G.camY;
      pinch.dist0=dist;
    } else if(pan.attivo && e.touches.length===1){
      const t=e.touches[0];
      const dx=t.clientX-pan.startX, dy=t.clientY-pan.startY;
      const rect=canvas.getBoundingClientRect();
      const _s=G.ISO_SCALE, _IW=G.ISO_W*_s, _IH=G.ISO_H*_s;
      const _lx=(t.clientX-rect.left)-G.camX, _ly=(t.clientY-rect.top)-G.camY;
      G.hoverC=Math.floor((_lx/_IW*2+_ly/_IH*2)/2-.5);
      G.hoverR=Math.floor((_ly/_IH*2-_lx/_IW*2)/2+.5);
      // Sentiero drag-paint su touch
      if(G.modalitaCostruzione==='sentiero'){
        piazzaSentiero(G.hoverR,G.hoverC); return;
      }
      if(Math.abs(dx)>12||Math.abs(dy)>12) pan.mosso=true;
      if(pan.mosso){ G.camX=pan.camStartX+dx; G.camY=pan.camStartY+dy; limiteCamera(); }
    }
  },{passive:false});

  canvas.addEventListener('touchend',e=>{
    if(pinch.attivo && e.touches.length<2){ pinch.attivo=false; }
    if(!pinch.attivo && !pan.mosso && e.changedTouches.length>0){
      const t=e.changedTouches[0];
      const rect=canvas.getBoundingClientRect();
      const _s2=G.ISO_SCALE,_IW2=G.ISO_W*_s2,_IH2=G.ISO_H*_s2;
      const _lx2=(t.clientX-rect.left)-G.camX, _ly2=(t.clientY-rect.top)-G.camY;
      const r=Math.floor((_ly2/_IH2*2-_lx2/_IW2*2)/2+.5);
      const c=Math.floor((_lx2/_IW2*2+_ly2/_IH2*2)/2-.5);
      G.hoverR=r; G.hoverC=c;
      if(G.modalitaCostruzione==='sentiero') piazzaSentiero(r,c);
      else if(G.modalitaCostruzione){ piazzaEdificio(r,c); }
      else{
        // Controlla edificio sul tile
        const b=G.edifici.find(x=>x.r===r&&x.c===c);
        if(b){ if(typeof apriPopupEdificio==='function') apriPopupEdificio(b); return; }
        const tt=(G.mappa[r]!==undefined)?G.mappa[r][c]:undefined;
        if(tt===undefined) return;
        const nomi={[T.OCEANO]:'Oceano',[T.BASSO]:'Acque Basse',[T.SABBIA]:'Spiaggia',[T.ERBA]:'Prato',[T.FORESTA]:'Foresta',[T.ROCCIA]:'Roccia',[T.COLLINA]:'Collina',[T.FIUME]:'Fiume',[T.SENTIERO]:'Sentiero',[T.PALUDE]:'Palude'};
        aggMsg('📍 '+(nomi[tt]||'?'));
      }
    }
    if(e.touches.length===0){ pan.attivo=false; pinch.attivo=false; }
  },{passive:false});

  window.addEventListener('resize', ()=>{ ridimensionaCanvas(); impostaMobile(); });
}

function getTile(e){
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left - G.camX;
  const my = e.clientY - rect.top  - G.camY;
  const s  = G.ISO_SCALE;
  const IW = G.ISO_W * s, IH = G.ISO_H * s;
  // Inverso proiezione iso: (mx,my) → (col,row)
  const col = Math.floor((mx/IW*2 + my/IH*2) / 2 - .5);
  const row = Math.floor((my/IH*2 - mx/IW*2) / 2 + .5);
  return { r:row, c:col };
}
function cliccaMappa(e){
  const{r,c}=getTile(e);
  if(G.modalitaCostruzione==='sentiero'){piazzaSentiero(r,c);return;}
  if(G.modalitaCostruzione){piazzaEdificio(r,c);return;}

  // 1. Edificio sul tile cliccato — priorità massima
  const b=G.edifici.find(x=>x.r===r&&x.c===c);
  if(b){
    if(typeof apriPopupEdificio==='function') apriPopupEdificio(b);
    return;
  }

  // 2. Pirata vicino al punto cliccato (coordinate schermo iso)
  const rect=canvas.getBoundingClientRect();
  const clickX=e.clientX-rect.left;
  const clickY=e.clientY-rect.top;
  const s=G.ISO_SCALE, IW=G.ISO_W*s, IH=G.ISO_H*s;
  for(const p of G.pirati){
    const proj=isoProj(p.mc,p.mr);
    const px=proj.x, py=proj.y+IH/2;
    if(Math.abs(clickX-px)<IW*0.5&&Math.abs(clickY-py)<IH*1.5){
      apriProfiloPirata(p.id);
      return;
    }
  }

  // 3. Info tile
  const t=(G.mappa[r]!==undefined)?G.mappa[r][c]:undefined;
  if(t===undefined) return;
  const nomi={[T.OCEANO]:'Oceano',[T.BASSO]:'Acque Basse',[T.SABBIA]:'Spiaggia',[T.ERBA]:'Prato',[T.FORESTA]:'Foresta',[T.ROCCIA]:'Roccia',[T.COLLINA]:'Collina',[T.FIUME]:'Fiume',[T.SENTIERO]:'Sentiero',[T.PALUDE]:'Palude'};
  aggMsg('📍 '+(nomi[t]||'?'));
}

// ── MODALE ──
function apriModale(titolo,html){
  document.getElementById('titolo-modale').textContent=titolo;
  document.getElementById('corpo-modale').innerHTML=html;
  document.getElementById('overlay-modale').classList.add('aperto');
}
function chiudiModale(){document.getElementById('overlay-modale').classList.remove('aperto');}
document.getElementById('overlay-modale').addEventListener('click',e=>{
  if(e.target===document.getElementById('overlay-modale')) chiudiModale();
});

// ── MESSAGGI & NOTIFICHE ──
function aggMsg(testo,tipo=''){
  const log=document.getElementById('log-msg');
  const d=document.createElement('div');
  d.className='msg'+(tipo?' '+tipo:'');
  d.textContent=testo;
  log.appendChild(d);
  while(log.children.length>4) log.removeChild(log.firstChild);
}
function notifica(titolo,corpo,tipo=''){
  const a=document.getElementById('area-notifiche');
  const d=document.createElement('div');
  d.className='notifica'+(tipo?' '+tipo:'');
  d.innerHTML=`<div class="titolo-notifica">${titolo}</div><div>${corpo}</div>`;
  a.appendChild(d);
  setTimeout(()=>{if(d.parentNode)d.remove();},5000);
}

// ── VELOCITÀ ──
// ── VELOCITÀ — stile Tropico 2: ⏸ Pausa / ▶ Normale / ▶▶ Veloce / ▶▶▶ Max ──
const VELOCITA_LIVELLI = [
  { val:0,   label:'⏸',       title:'Pausa'  },
  { val:1,   label:'▶',       title:'Normale' },
  { val:2.5, label:'▶▶',      title:'Veloce'  },
  { val:6,   label:'▶▶▶',     title:'Max'     },
];
let _velIdx = 1; // parte in Normale

function cambiaVelocita(){
  _velIdx = (_velIdx + 1) % VELOCITA_LIVELLI.length;
  const lv = VELOCITA_LIVELLI[_velIdx];
  G.velocita = lv.val;
  const btn = document.getElementById('btn-velocita');
  if(btn){ btn.textContent = lv.label; btn.title = lv.title; }
  // Musica: mantieni ritmo costante indipendentemente dalla velocità
  if(typeof MUSIC !== 'undefined'){
    if(G.velocita === 0) { /* pausa: musica continua ma il tick si ferma */ }
  }
}

function impostaVelocitaUI(){
  const lv = VELOCITA_LIVELLI[_velIdx];
  const btn = document.getElementById('btn-velocita');
  if(btn){ btn.textContent = lv.label; btn.title = lv.title; }
}

// ── CICLO GIOCO ──
// ═══════════════════════════════════════════════════
// CONDIZIONI VITTORIA / SCONFITTA
// ═══════════════════════════════════════════════════

// Obiettivi vittoria — tutti devono essere soddisfatti

// ── MUSICA ──
function toggleMusica(){
  const on = MUSIC.toggle();
  const btn = document.getElementById('btn-musica');
  if(btn) btn.textContent = on ? '🔊' : '🎵';
}

// Avvia musica al primo click utente (policy browser)
function avviaMusicaAlPrimoClick(){
  if(MUSIC.isRunning()) return;
  MUSIC.start();
  const btn = document.getElementById('btn-musica');
  if(btn) btn.textContent = '🔊';
  document.removeEventListener('click', avviaMusicaAlPrimoClick);
}
